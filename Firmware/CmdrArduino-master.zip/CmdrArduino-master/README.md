CmdrArduino
===========

To install, see the general instructions for Arduino library installation here:
http://arduino.cc/en/Guide/Environment#libraries

Discussion
----------

You can get support for the CmdrArduino software at the Railstars [Support Forum](http://support.railstars.com/index.php?p=/categories/cmdrarduino)

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/Railstars/cmdrarduino/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
